/**
 * Script principal pour le Festival des Arts et Traditions de Bamako
 * Animations et interactions enrichies
 */

document.addEventListener('DOMContentLoaded', function() {
    // Variables globales
    const header = document.querySelector('header');
    const menuToggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('nav');
    const backToTopBtn = document.querySelector('.back-to-top');
    
    // Initialisation des animations au chargement
    initAnimations();
    
    // Initialisation des événements
    initEvents();
    
    // Initialisation des composants interactifs
    initGallery();
    initProgramTabs();
    initAudioPlayer();
    initScrollEffects();
    initCounters();
    initTestimonials();
    
    /**
     * Initialise les animations de base au chargement de la page
     */
    function initAnimations() {
        // Animation du header au chargement
        gsap.from('header', {
            y: -100,
            opacity: 0,
            duration: 1,
            ease: 'power3.out'
        });
        
        // Animation des éléments de la section hero
        gsap.from('.hero-content > *', {
            y: 50,
            opacity: 0,
            duration: 1,
            stagger: 0.2,
            ease: 'power3.out',
            delay: 0.5
        });
        
        // Animation des sections au chargement initial
        gsap.utils.toArray('.section-title').forEach(title => {
            gsap.from(title, {
                y: 50,
                opacity: 0,
                duration: 1,
                scrollTrigger: {
                    trigger: title,
                    start: 'top 80%',
                    toggleActions: 'play none none none'
                }
            });
        });
    }
    
    /**
     * Initialise tous les événements d'interaction
     */
    function initEvents() {
        // Menu hamburger pour mobile
        if (menuToggle) {
            menuToggle.addEventListener('click', function() {
                menuToggle.classList.toggle('active');
                nav.classList.toggle('active');
                
                // Animation du menu
                if (nav.classList.contains('active')) {
                    gsap.from('nav ul li', {
                        x: -50,
                        opacity: 0,
                        duration: 0.5,
                        stagger: 0.1,
                        ease: 'power3.out'
                    });
                }
            });
        }
        
        // Header sticky au scroll
        window.addEventListener('scroll', function() {
            if (window.scrollY > 100) {
                header.classList.add('sticky');
                if (backToTopBtn) backToTopBtn.classList.add('visible');
            } else {
                header.classList.remove('sticky');
                if (backToTopBtn) backToTopBtn.classList.remove('visible');
            }
        });
        
        // Bouton retour en haut
        if (backToTopBtn) {
            backToTopBtn.addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
        }
        
        // Animation des liens de navigation
        document.querySelectorAll('nav a').forEach(link => {
            link.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                
                // Si c'est un lien interne avec ancre
                if (href.startsWith('#') && href.length > 1) {
                    e.preventDefault();
                    const targetSection = document.querySelector(href);
                    
                    if (targetSection) {
                        // Fermer le menu mobile si ouvert
                        if (nav.classList.contains('active')) {
                            menuToggle.classList.remove('active');
                            nav.classList.remove('active');
                        }
                        
                        // Scroll vers la section
                        window.scrollTo({
                            top: targetSection.offsetTop - header.offsetHeight,
                            behavior: 'smooth'
                        });
                    }
                }
            });
        });
    }
    
    /**
     * Initialise la galerie avec lightbox
     */
    function initGallery() {
        const galleryItems = document.querySelectorAll('.gallery-item');
        const lightbox = document.querySelector('.lightbox');
        
        if (!galleryItems.length || !lightbox) return;
        
        const lightboxImage = lightbox.querySelector('.lightbox-image');
        const lightboxClose = lightbox.querySelector('.lightbox-close');
        const lightboxPrev = lightbox.querySelector('.lightbox-prev');
        const lightboxNext = lightbox.querySelector('.lightbox-next');
        
        let currentIndex = 0;
        
        // Ouvrir la lightbox au clic sur une image
        galleryItems.forEach((item, index) => {
            item.addEventListener('click', function() {
                const imgSrc = this.querySelector('img').getAttribute('src');
                currentIndex = index;
                openLightbox(imgSrc);
            });
            
            // Animation au survol
            item.addEventListener('mouseenter', function() {
                gsap.to(this.querySelector('img'), {
                    scale: 1.1,
                    duration: 0.5
                });
                gsap.to(this.querySelector('.gallery-overlay'), {
                    y: 0,
                    opacity: 1,
                    duration: 0.3
                });
            });
            
            item.addEventListener('mouseleave', function() {
                gsap.to(this.querySelector('img'), {
                    scale: 1,
                    duration: 0.5
                });
                gsap.to(this.querySelector('.gallery-overlay'), {
                    y: '100%',
                    opacity: 0,
                    duration: 0.3
                });
            });
        });
        
        // Fermer la lightbox
        if (lightboxClose) {
            lightboxClose.addEventListener('click', closeLightbox);
        }
        
        // Navigation dans la lightbox
        if (lightboxPrev) {
            lightboxPrev.addEventListener('click', function() {
                currentIndex = (currentIndex - 1 + galleryItems.length) % galleryItems.length;
                const imgSrc = galleryItems[currentIndex].querySelector('img').getAttribute('src');
                updateLightboxImage(imgSrc);
            });
        }
        
        if (lightboxNext) {
            lightboxNext.addEventListener('click', function() {
                currentIndex = (currentIndex + 1) % galleryItems.length;
                const imgSrc = galleryItems[currentIndex].querySelector('img').getAttribute('src');
                updateLightboxImage(imgSrc);
            });
        }
        
        // Fermer la lightbox avec la touche Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && lightbox.classList.contains('active')) {
                closeLightbox();
            }
        });
        
        // Fonction pour ouvrir la lightbox
        function openLightbox(imgSrc) {
            if (lightboxImage) lightboxImage.setAttribute('src', imgSrc);
            lightbox.classList.add('active');
            
            // Animation d'ouverture
            gsap.fromTo(lightboxImage, 
                { scale: 0.8, opacity: 0 },
                { scale: 1, opacity: 1, duration: 0.5 }
            );
            
            // Désactiver le scroll du body
            document.body.style.overflow = 'hidden';
        }
        
        // Fonction pour fermer la lightbox
        function closeLightbox() {
            gsap.to(lightboxImage, {
                scale: 0.8,
                opacity: 0,
                duration: 0.3,
                onComplete: () => {
                    lightbox.classList.remove('active');
                    // Réactiver le scroll du body
                    document.body.style.overflow = '';
                }
            });
        }
        
        // Fonction pour mettre à jour l'image de la lightbox
        function updateLightboxImage(imgSrc) {
            gsap.to(lightboxImage, {
                opacity: 0,
                scale: 0.8,
                duration: 0.3,
                onComplete: () => {
                    lightboxImage.setAttribute('src', imgSrc);
                    gsap.to(lightboxImage, {
                        opacity: 1,
                        scale: 1,
                        duration: 0.3
                    });
                }
            });
        }
    }
    
    /**
     * Initialise les onglets du programme
     */
    function initProgramTabs() {
        const dayTabs = document.querySelectorAll('.day-tab');
        const dayContents = document.querySelectorAll('.day-content');
        
        if (!dayTabs.length || !dayContents.length) return;
        
        dayTabs.forEach((tab, index) => {
            tab.addEventListener('click', function() {
                // Désactiver tous les onglets et contenus
                dayTabs.forEach(t => t.classList.remove('active'));
                dayContents.forEach(c => c.classList.remove('active'));
                
                // Activer l'onglet et le contenu cliqués
                this.classList.add('active');
                dayContents[index].classList.add('active');
                
                // Animation du contenu
                gsap.fromTo(dayContents[index].querySelectorAll('.event'),
                    { y: 20, opacity: 0 },
                    { 
                        y: 0, 
                        opacity: 1, 
                        duration: 0.5, 
                        stagger: 0.1,
                        ease: 'power3.out'
                    }
                );
            });
        });
        
        // Animation des événements au survol
        document.querySelectorAll('.event').forEach(event => {
            event.addEventListener('mouseenter', function() {
                gsap.to(this, {
                    y: -5,
                    boxShadow: '0 8px 20px rgba(0, 0, 0, 0.1)',
                    duration: 0.3
                });
            });
            
            event.addEventListener('mouseleave', function() {
                gsap.to(this, {
                    y: 0,
                    boxShadow: '0 5px 15px rgba(0, 0, 0, 0.05)',
                    duration: 0.3
                });
            });
        });
    }
    
    /**
     * Initialise le lecteur audio personnalisé
     */
    function initAudioPlayer() {
        const audioPlayers = document.querySelectorAll('.custom-audio-player');
        
        audioPlayers.forEach(player => {
            const audio = player.querySelector('audio');
            const playBtn = player.querySelector('.play-btn');
            const progressBar = player.querySelector('.progress-bar');
            const progressContainer = player.querySelector('.progress-container');
            const timeDisplay = player.querySelector('.time-display');
            
            if (!audio || !playBtn || !progressBar || !progressContainer || !timeDisplay) return;
            
            // Jouer/Pauser l'audio
            playBtn.addEventListener('click', function() {
                if (audio.paused) {
                    audio.play();
                    this.innerHTML = '<i class="fas fa-pause"></i>';
                } else {
                    audio.pause();
                    this.innerHTML = '<i class="fas fa-play"></i>';
                }
            });
            
            // Mettre à jour la barre de progression
            audio.addEventListener('timeupdate', function() {
                const progress = (this.currentTime / this.duration) * 100;
                progressBar.style.width = `${progress}%`;
                
                // Mettre à jour l'affichage du temps
                const currentMinutes = Math.floor(this.currentTime / 60);
                const currentSeconds = Math.floor(this.currentTime % 60);
                const durationMinutes = Math.floor(this.duration / 60);
                const durationSeconds = Math.floor(this.duration % 60);
                
                timeDisplay.textContent = `${currentMinutes}:${currentSeconds < 10 ? '0' : ''}${currentSeconds} / ${durationMinutes}:${durationSeconds < 10 ? '0' : ''}${durationSeconds}`;
            });
            
            // Changer la position de lecture
            progressContainer.addEventListener('click', function(e) {
                const clickPosition = (e.offsetX / this.offsetWidth);
                audio.currentTime = clickPosition * audio.duration;
            });
            
            // Réinitialiser le bouton à la fin de la lecture
            audio.addEventListener('ended', function() {
                playBtn.innerHTML = '<i class="fas fa-play"></i>';
            });
        });
    }
    
    /**
     * Initialise les effets de défilement
     */
    function initScrollEffects() {
        // Animation des éléments au défilement
        gsap.utils.toArray('.scroll-reveal').forEach(element => {
            gsap.from(element, {
                y: 50,
                opacity: 0,
                duration: 0.8,
                scrollTrigger: {
                    trigger: element,
                    start: 'top 80%',
                    toggleActions: 'play none none none'
                }
            });
        });
        
        // Animation des cartes au défilement
        gsap.utils.toArray('.card').forEach(card => {
            gsap.from(card, {
                y: 50,
                opacity: 0,
                duration: 0.8,
                scrollTrigger: {
                    trigger: card,
                    start: 'top 80%',
                    toggleActions: 'play none none none'
                }
            });
            
            // Animation au survol
            card.addEventListener('mouseenter', function() {
                gsap.to(this, {
                    y: -10,
                    boxShadow: '0 15px 30px rgba(0, 0, 0, 0.1)',
                    duration: 0.3
                });
            });
            
            card.addEventListener('mouseleave', function() {
                gsap.to(this, {
                    y: 0,
                    boxShadow: '0 5px 15px rgba(0, 0, 0, 0.05)',
                    duration: 0.3
                });
            });
        });
        
        // Effet parallaxe pour les sections avec classe .parallax
        gsap.utils.toArray('.parallax').forEach(section => {
            gsap.to(section, {
                backgroundPosition: `50% ${innerHeight / 2}px`,
                ease: 'none',
                scrollTrigger: {
                    trigger: section,
                    start: 'top bottom',
                    end: 'bottom top',
                    scrub: true
                }
            });
        });
    }
    
    /**
     * Initialise les compteurs animés
     */
    function initCounters() {
        const counterItems = document.querySelectorAll('.counter-value');
        
        counterItems.forEach(counter => {
            const target = parseInt(counter.getAttribute('data-target'));
            
            gsap.to(counter, {
                innerHTML: target,
                duration: 2,
                snap: { innerHTML: 1 },
                scrollTrigger: {
                    trigger: counter,
                    start: 'top 80%',
                    toggleActions: 'play none none none'
                },
                onUpdate: function() {
                    counter.textContent = Math.ceil(counter.innerHTML);
                }
            });
        });
    }
    
    /**
     * Initialise le carrousel de témoignages
     */
    function initTestimonials() {
        const testimonialContainer = document.querySelector('.testimonial-container');
        const testimonials = document.querySelectorAll('.testimonial');
        const dots = document.querySelectorAll('.testimonial-dot');
        
        if (!testimonialContainer || !testimonials.length) return;
        
        let currentIndex = 0;
        const testimonialWidth = testimonials[0].offsetWidth;
        
        // Initialiser les points de navigation
        dots.forEach((dot, index) => {
            dot.addEventListener('click', function() {
                goToSlide(index);
            });
        });
        
        // Fonction pour aller à un témoignage spécifique
        function goToSlide(index) {
            currentIndex = index;
            
            // Mettre à jour les points de navigation
            dots.forEach(d => d.classList.remove('active'));
            dots[currentIndex].classList.add('active');
            
            // Animer le déplacement
            gsap.to(testimonialContainer, {
                x: -currentIndex * testimonialWidth,
                duration: 0.5,
                ease: 'power2.out'
            });
        }
        
        // Défilement automatique
        let interval = setInterval(() => {
            currentIndex = (currentIndex + 1) % testimonials.length;
            goToSlide(currentIndex);
        }, 5000);
        
        // Arrêter le défilement automatique au survol
        testimonialContainer.addEventListener('mouseenter', () => {
            clearInterval(interval);
        });
        
        // Reprendre le défilement automatique à la sortie
        testimonialContainer.addEventListener('mouseleave', () => {
            interval = setInterval(() => {
                currentIndex = (currentIndex + 1) % testimonials.length;
                goToSlide(currentIndex);
            }, 5000);
        });
    }
    
    /**
     * Affiche une notification
     * @param {string} message - Le message à afficher
     * @param {string} type - Le type de notification (success, error, info)
     */
    function showNotification(message, type = 'success') {
        // Créer l'élément de notification
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        // Ajouter au DOM
        document.body.appendChild(notification);
        
        // Animer l'apparition
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // Supprimer après 3 secondes
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 500);
        }, 3000);
    }
    
    /**
     * Initialise le formulaire de contact
     */
    function initContactForm() {
        const contactForm = document.querySelector('.contact-form');
        
        if (!contactForm) return;
        
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Simuler l'envoi du formulaire
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            
            submitBtn.disabled = true;
            submitBtn.textContent = 'Envoi en cours...';
            
            // Simuler un délai d'envoi
            setTimeout(() => {
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
                
                // Réinitialiser le formulaire
                this.reset();
                
                // Afficher une notification
                showNotification('Votre message a été envoyé avec succès !');
            }, 1500);
        });
    }
    
    // Initialiser le formulaire de contact
    initContactForm();
    
    // Ajouter des effets de transition de page
    function initPageTransitions() {
        // Créer l'élément de transition
        const transition = document.createElement('div');
        transition.className = 'page-transition';
        document.body.appendChild(transition);
        
        // Gérer les liens internes
        document.querySelectorAll('a[href^="/"]:not([href*="#"])').forEach(link => {
            link.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                
                if (href && !href.includes('#')) {
                    e.preventDefault();
                    
                    // Animer la transition
                    transition.classList.add('active');
                    
                    // Rediriger après l'animation
                    setTimeout(() => {
                        window.location.href = href;
                    }, 500);
                }
            });
        });
    }
    
    // Initialiser les transitions de page
    initPageTransitions();
    
    // Ajouter des effets de particules pour la section hero
    function initParticles() {
        const heroSection = document.querySelector('.hero');
        
        if (!heroSection) return;
        
        // Créer le canvas pour les particules
        const canvas = document.createElement('canvas');
        canvas.className = 'particles-canvas';
        canvas.style.position = 'absolute';
        canvas.style.top = '0';
        canvas.style.left = '0';
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        canvas.style.zIndex = '0';
        
        heroSection.appendChild(canvas);
        
        // Configuration des particules
        const particlesConfig = {
            particles: {
                number: {
                    value: 50,
                    density: {
                        enable: true,
                        value_area: 800
                    }
                },
                color: {
                    value: '#ffffff'
                },
                shape: {
                    type: 'circle'
                },
                opacity: {
                    value: 0.5,
                    random: true
                },
                size: {
                    value: 3,
                    random: true
                },
                line_linked: {
                    enable: true,
                    distance: 150,
                    color: '#ffffff',
                    opacity: 0.2,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 2,
                    direction: 'none',
                    random: true,
                    straight: false,
                    out_mode: 'out',
                    bounce: false
                }
            },
            interactivity: {
                detect_on: 'canvas',
                events: {
                    onhover: {
                        enable: true,
                        mode: 'grab'
                    },
                    onclick: {
                        enable: true,
                        mode: 'push'
                    },
                    resize: true
                }
            },
            retina_detect: true
        };
        
        // Initialiser les particules si la bibliothèque est disponible
        if (typeof particlesJS !== 'undefined') {
            particlesJS('particles-canvas', particlesConfig);
        }
    }
    
    // Initialiser les particules si la section hero existe
    initParticles();
});

/**
 * Fonction pour animer les éléments au défilement
 * Cette fonction est appelée en dehors du DOMContentLoaded pour être disponible globalement
 */
function animateOnScroll() {
    const elements = document.querySelectorAll('.animate-on-scroll');
    
    elements.forEach(element => {
        const elementPosition = element.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
        
        if (elementPosition < windowHeight * 0.8) {
            element.classList.add('visible');
        }
    });
}

// Ajouter l'événement de défilement pour les animations
window.addEventListener('scroll', animateOnScroll);

// Déclencher une fois au chargement
window.addEventListener('load', animateOnScroll);
