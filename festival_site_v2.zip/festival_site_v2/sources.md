# Sources des médias utilisés

## Images
- tambours_africains.jpeg : Image de tambours africains traditionnels colorés, source: Pixabay, licence libre
- danseur_africain_traditionnel.jpeg : Image d'un danseur africain avec peintures traditionnelles, source: Pexels (Alva Shoot), licence libre
- danseuse_africaine.jpeg : Image d'une danseuse en mouvement, source: Unsplash (Getty Images), licence libre
- festival_enfant_africain.jpeg : Image d'un enfant lors d'un festival, source: Unsplash, licence libre
- festival_musique_couleurs.jpeg : Image d'un festival de musique avec jeux de lumières colorés, source: Pixabay (Ostrovsky), licence libre

## Vidéos
- concert_lights.mp4 : Vidéo d'ambiance de concert avec jeux de lumières, source: Pixabay, licence libre
- cassettes.mp4 : Vidéo de cassettes audio vintage, source: Pixabay, licence libre

## Audio
- african_night.mp3 : Musique africaine traditionnelle, source: Pixabay, licence libre
